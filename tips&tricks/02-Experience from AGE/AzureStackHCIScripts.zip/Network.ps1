﻿Install-WindowsFeature -Name "BitLocker", "Data-Center-Bridging", "Failover-Clustering", "FS-FileServer", "FS-Data-Deduplication", "FS-SMBBW", "Hyper-V", "Hyper-V-PowerShell", "RSAT-AD-Powershell", "RSAT-Clustering-PowerShell", "NetworkATC", "NetworkHUD", "Storage-Replica" -IncludeAllSubFeature -IncludeManagementTools

Get-WinUILanguageOverride

# Block DCBX protocol between switches and nodes (for future node expansion)
Set-NetQosDcbxSetting -InterfaceAlias "SMB-Port-1" -Willing $False
Set-NetQosDcbxSetting -InterfaceAlias "SMB-Port-2" -Willing $False
New-NetQosPolicy -Name "SMB" -NetDirectPortMatchCondition 445 -PriorityValue8021Action 3
New-NetQosPolicy -Name "Cluster-HB" -Cluster -PriorityValue8021Action 7
New-NetQosPolicy -Name "Default" -Default -PriorityValue8021Action 0
Enable-NetQosFlowControl -Priority 3
Disable-NetQosFlowControl -Priority 0,1,2,4,5,6,7
Enable-NetAdapterQos -Name "SMB-Port-1"
Enable-NetAdapterQos -Name "SMB-Port-2"
New-NetQosTrafficClass "SMB" -Priority 3 -BandwidthPercentage 50 -Algorithm ETS
New-NetQosTrafficClass "Cluster-HB" -Priority 7 -BandwidthPercentage 1 -Algorithm ETS
Set-NetAdapterAdvancedProperty -Name "SMB-Port-1" -RegistryKeyword "*FlowControl" -RegistryValue 0
Set-NetAdapterAdvancedProperty -Name "SMB-Port-2" -RegistryKeyword "*FlowControl" -RegistryValue 0



# Configure IP and subnet mask, no default gateway for Storage interfaces
New-NetIPAddress -InterfaceAlias "SMB-Port-1" -IPAddress 192.168.100.1 -PrefixLength 24
New-NetIPAddress -InterfaceAlias "SMB-Port-2" -IPAddress 192.168.101.1 -PrefixLength 24
Set-NetAdapter -Name "SMB-Port-1" -VlanID 100
Set-NetAdapter -Name "SMB-Port-2" -VlanID 101

New-NetIPAddress -InterfaceAlias "SMB-Port-1" -IPAddress 192.168.100.2 -PrefixLength 24
New-NetIPAddress -InterfaceAlias "SMB-Port-2" -IPAddress 192.168.101.2 -PrefixLength 24 
Set-NetAdapter -Name "SMB-Port-1" -VlanID 100 -Confirm
Set-NetAdapter -Name "SMB-Port-2" -VlanID 101 -Confirm

# Configure DNS on each interface, but do not register Storage interfaces
Set-DnsClient -InterfaceAlias "SMB-Port-1" -RegisterThisConnectionsAddress $false

Set-DnsClient -InterfaceAlias "SMB-Port-2" -RegisterThisConnectionsAddress $false

# Create SET-enabled vSwitch for Hyper-V using 2 OCP ports
New-VMSwitch -Name "MGMT-vSwitch" -NetAdapterName "OCP-Port-4", "OCP-Port-3" -EnableEmbeddedTeaming $true -AllowManagementOS $false
Add-VMNetworkAdapter -SwitchName "MGMT-vSwitch" -Name "vNIC-Host" -ManagementOS
New-NetIPAddress -InterfaceAlias "vEthernet (vNIC-Host)" -IPAddress 10.15.122.215 -PrefixLength 24 -DefaultGateway 10.15.122.200
Set-DnsClientServerAddress -InterfaceAlias "vEthernet (vNIC-Host)" -ServerAddresses ("10.15.121.81","10.15.121.210")

# Create SET-enabled vSwitch for Hyper-V using 2 OCP ports
New-VMSwitch -Name "COMPUTE-vSwitch" -NetAdapterName "OCP-Port-2", "OCP-Port-1" -EnableEmbeddedTeaming $true -AllowManagementOS $false
