﻿#register Azure Stack HCI cluster as Azure Arc resource (pre-requisites to deploy any vm on Azure Stack HCI)
# https://docs.microsoft.com/en-us/azure-stack/hci/deploy/register-with-azure
 
# variables used in the script, update them accordingly based on your environment before proceed further
$tenant = "bestserv1.onmicrosoft.com"
$subscriptionID = "8497e1df-7bc1-4946-8830-540e1ae03aa4"
$rgName = "BS-AZS-Cluster"
$location = "westeurope"
$hciHostName = "BS-AZS-N1"
$hciClusterName = "BS-AZS-Cluster"
 
Install-Module az
Install-Module AzureAD
Install-Module -Name Az.StackHCI
Install-Module Az.Resources
Connect-AzAccount -Tenant $tenant
Select-AzSubscription -Subscription $subscriptionID
$rg = get-AzResourceGroup -Name $rgName -Location $location
Register-AzStackHCI  -SubscriptionId $subscriptionID -ComputerName $hciHostName -ResourceName $hciClusterName -ResourceGroupName $rg.ResourceGroupName -Region $rg.location 
